import './App.css'
import AboutUs from './components/landingPage/AboutUs'
import ContactUs from './components/landingPage/ContactUs'
import Destination from './components/landingPage/Destination'
import Footer from './components/landingPage/Footer'
import Header from './components/landingPage/Header'

function App() {

  return (
    <>
      <Header />
      <AboutUs />
      <Destination />
      <ContactUs />
      <Footer />
    </>
  )
}

export default App
